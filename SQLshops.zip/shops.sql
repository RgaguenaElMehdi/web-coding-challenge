/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50719
Source Host           : localhost:3306
Source Database       : shops

Target Server Type    : MYSQL
Target Server Version : 50719
File Encoding         : 65001

Date: 2018-04-19 15:26:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for dislikes
-- ----------------------------
DROP TABLE IF EXISTS `dislikes`;
CREATE TABLE `dislikes` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `u_id` int(100) NOT NULL,
  `s_id` varchar(24) NOT NULL,
  `created_at` timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `u_id` (`u_id`) USING BTREE,
  KEY `s_id` (`s_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 ROW_FORMAT=FIXED;

-- ----------------------------
-- Records of dislikes
-- ----------------------------

-- ----------------------------
-- Table structure for likes
-- ----------------------------
DROP TABLE IF EXISTS `likes`;
CREATE TABLE `likes` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `u_id` int(100) NOT NULL,
  `s_id` varchar(24) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `u_id` (`u_id`),
  KEY `s_id` (`s_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of likes
-- ----------------------------

-- ----------------------------
-- Table structure for password_resets
-- ----------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of password_resets
-- ----------------------------

-- ----------------------------
-- Table structure for shops
-- ----------------------------
DROP TABLE IF EXISTS `shops`;
CREATE TABLE `shops` (
  `id_oid` varchar(24) CHARACTER SET utf8 DEFAULT NULL,
  `picture` varchar(27) CHARACTER SET utf8 DEFAULT NULL,
  `name` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(23) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `location_type` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `location_coordinates_0` decimal(6,5) DEFAULT NULL,
  `location_coordinates_1` decimal(7,5) DEFAULT NULL,
  KEY `id_oid` (`id_oid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of shops
-- ----------------------------
INSERT INTO `shops` VALUES ('5a0c6711fb3aac66aafe26c4', 'http://placehold.it/150x150', 'Gushkool', 'leilaware@gushkool.com', 'Rabat', 'Point', '-6.81134', '33.95564');
INSERT INTO `shops` VALUES ('5a0c6711fb3aac66aafe26c5', 'http://placehold.it/150x150', 'Datagene', 'leilaware@datagene.com', 'Rabat', 'Point', '-6.83746', '33.91183');
INSERT INTO `shops` VALUES ('5a0c6711fb3aac66aafe26c6', 'http://placehold.it/150x150', 'Silodyne', 'leilaware@silodyne.com', 'Rabat', 'Point', '-6.75175', '33.96853');
INSERT INTO `shops` VALUES ('5a0c6711fb3aac66aafe26c7', 'http://placehold.it/150x150', 'Canopoly', 'leilaware@canopoly.com', 'Rabat', 'Point', '-6.77404', '33.80354');
INSERT INTO `shops` VALUES ('5a0c6711fb3aac66aafe26c8', 'http://placehold.it/150x150', 'Sonique', 'leilaware@sonique.com', 'Rabat', 'Point', '-6.74938', '33.83436');
INSERT INTO `shops` VALUES ('5a0c6711fb3aac66aafe26c9', 'http://placehold.it/150x150', 'Quiltigen', 'leilaware@quiltigen.com', 'Rabat', 'Point', '-6.84286', '33.96579');
INSERT INTO `shops` VALUES ('5a0c6711fb3aac66aafe26ca', 'http://placehold.it/150x150', 'Infotrips', 'leilaware@infotrips.com', 'Rabat', 'Point', '-6.80604', '33.94889');
INSERT INTO `shops` VALUES ('5a0c6711fb3aac66aafe26cb', 'http://placehold.it/150x150', 'Biflex', 'leilaware@biflex.com', 'Rabat', 'Point', '-6.81230', '33.86261');
INSERT INTO `shops` VALUES ('5a0c6711fb3aac66aafe26cc', 'http://placehold.it/150x150', 'Permadyne', 'leilaware@permadyne.com', 'Rabat', 'Point', '-6.75058', '33.81395');
INSERT INTO `shops` VALUES ('5a0c6711fb3aac66aafe26cd', 'http://placehold.it/150x150', 'Bunga', 'leilaware@bunga.com', 'Rabat', 'Point', '-6.77428', '33.94109');
INSERT INTO `shops` VALUES ('5a0c6711fb3aac66aafe26ce', 'http://placehold.it/150x150', 'Vendblend', 'leilaware@vendblend.com', 'Rabat', 'Point', '-6.78522', '33.89471');
INSERT INTO `shops` VALUES ('5a0c6711fb3aac66aafe26cf', 'http://placehold.it/150x150', 'Strezzo', 'leilaware@strezzo.com', 'Rabat', 'Point', '-6.78271', '33.80210');
INSERT INTO `shops` VALUES ('5a0c6711fb3aac66aafe26d0', 'http://placehold.it/150x150', 'Multiflex', 'leilaware@multiflex.com', 'Rabat', 'Point', '-6.84318', '33.91423');
INSERT INTO `shops` VALUES ('5a0c6711fb3aac66aafe26d1', 'http://placehold.it/150x150', 'Amtas', 'leilaware@amtas.com', 'Rabat', 'Point', '-6.76681', '33.92546');
INSERT INTO `shops` VALUES ('5a0c6711fb3aac66aafe26d2', 'http://placehold.it/150x150', 'Medmex', 'leilaware@medmex.com', 'Rabat', 'Point', '-6.75185', '33.89586');
INSERT INTO `shops` VALUES ('5a0c6711fb3aac66aafe26d3', 'http://placehold.it/150x150', 'Limozen', 'leilaware@limozen.com', 'Rabat', 'Point', '-6.84619', '33.94625');
INSERT INTO `shops` VALUES ('5a0c6711fb3aac66aafe26d4', 'http://placehold.it/150x150', 'Securia', 'leilaware@securia.com', 'Rabat', 'Point', '-6.82966', '33.94125');
INSERT INTO `shops` VALUES ('5a0c6748fb3aac66aafe26d5', 'http://placehold.it/150x150', 'Enerforce', 'leilaware@enerforce.com', 'Rabat', 'Point', '-6.79465', '33.97383');
INSERT INTO `shops` VALUES ('5a0c6748fb3aac66aafe26d6', 'http://placehold.it/150x150', 'Earwax', 'leilaware@earwax.com', 'Rabat', 'Point', '-6.81943', '33.87998');
INSERT INTO `shops` VALUES ('5a0c6748fb3aac66aafe26d7', 'http://placehold.it/150x150', 'Cablam', 'leilaware@cablam.com', 'Rabat', 'Point', '-6.75778', '33.97468');
INSERT INTO `shops` VALUES ('5a0c6748fb3aac66aafe26d8', 'http://placehold.it/150x150', 'Emoltra', 'leilaware@emoltra.com', 'Rabat', 'Point', '-6.78269', '33.91448');
INSERT INTO `shops` VALUES ('5a0c6748fb3aac66aafe26d9', 'http://placehold.it/150x150', 'Tubalum', 'leilaware@tubalum.com', 'Rabat', 'Point', '-6.79337', '33.80098');
INSERT INTO `shops` VALUES ('5a0c6748fb3aac66aafe26da', 'http://placehold.it/150x150', 'Toyletry', 'leilaware@toyletry.com', 'Rabat', 'Point', '-6.75454', '33.82381');
INSERT INTO `shops` VALUES ('5a0c6748fb3aac66aafe26db', 'http://placehold.it/150x150', 'Comveyor', 'leilaware@comveyor.com', 'Rabat', 'Point', '-6.75603', '33.85214');
INSERT INTO `shops` VALUES ('5a0c6748fb3aac66aafe26dc', 'http://placehold.it/150x150', 'Techmania', 'leilaware@techmania.com', 'Rabat', 'Point', '-6.80777', '33.98156');
INSERT INTO `shops` VALUES ('5a0c6748fb3aac66aafe26dd', 'http://placehold.it/150x150', 'Peticular', 'leilaware@peticular.com', 'Rabat', 'Point', '-6.78231', '33.83055');
INSERT INTO `shops` VALUES ('5a0c6748fb3aac66aafe26de', 'http://placehold.it/150x150', 'Teraprene', 'leilaware@teraprene.com', 'Rabat', 'Point', '-6.84167', '33.81279');
INSERT INTO `shops` VALUES ('5a0c6755fb3aac66aafe26df', 'http://placehold.it/150x150', 'Quarex', 'leilaware@quarex.com', 'Rabat', 'Point', '-6.78929', '33.82861');
INSERT INTO `shops` VALUES ('5a0c6755fb3aac66aafe26e0', 'http://placehold.it/150x150', 'Kiggle', 'leilaware@kiggle.com', 'Rabat', 'Point', '-6.82440', '33.80087');
INSERT INTO `shops` VALUES ('5a0c6755fb3aac66aafe26e1', 'http://placehold.it/150x150', 'Amtap', 'leilaware@amtap.com', 'Rabat', 'Point', '-6.77772', '33.94732');
INSERT INTO `shops` VALUES ('5a0c6755fb3aac66aafe26e2', 'http://placehold.it/150x150', 'Maxemia', 'leilaware@maxemia.com', 'Rabat', 'Point', '-6.79656', '33.82961');
INSERT INTO `shops` VALUES ('5a0c6789fd3eb67969316ccc', 'http://placehold.it/150x150', 'Splinx', 'leilaware@splinx.com', 'Rabat', 'Point', '-6.76639', '33.96536');
INSERT INTO `shops` VALUES ('5a0c6789fd3eb67969316ccd', 'http://placehold.it/150x150', 'Plexia', 'leilaware@plexia.com', 'Rabat', 'Point', '-6.77151', '33.97996');
INSERT INTO `shops` VALUES ('5a0c6789fd3eb67969316cce', 'http://placehold.it/150x150', 'Zytrax', 'leilaware@zytrax.com', 'Rabat', 'Point', '-6.75629', '33.81514');
INSERT INTO `shops` VALUES ('5a0c6789fd3eb67969316ccf', 'http://placehold.it/150x150', 'Nebulean', 'leilaware@nebulean.com', 'Rabat', 'Point', '-6.80549', '33.84752');
INSERT INTO `shops` VALUES ('5a0c6789fd3eb67969316cd0', 'http://placehold.it/150x150', 'Chillium', 'leilaware@chillium.com', 'Rabat', 'Point', '-6.80111', '33.83202');
INSERT INTO `shops` VALUES ('5a0c6789fd3eb67969316cd1', 'http://placehold.it/150x150', 'Bitendrex', 'leilaware@bitendrex.com', 'Rabat', 'Point', '-6.80479', '33.83069');
INSERT INTO `shops` VALUES ('5a0c6789fd3eb67969316cd2', 'http://placehold.it/150x150', 'Assitia', 'leilaware@assitia.com', 'Rabat', 'Point', '-6.75229', '33.94719');
INSERT INTO `shops` VALUES ('5a0c6789fd3eb67969316cd3', 'http://placehold.it/150x150', 'Apexia', 'leilaware@apexia.com', 'Rabat', 'Point', '-6.81765', '33.91963');
INSERT INTO `shops` VALUES ('5a0c6789fd3eb67969316cd4', 'http://placehold.it/150x150', 'Hopeli', 'leilaware@hopeli.com', 'Rabat', 'Point', '-6.75449', '33.85677');
INSERT INTO `shops` VALUES ('5a0c6789fd3eb67969316cd5', 'http://placehold.it/150x150', 'Tingles', 'leilaware@tingles.com', 'Rabat', 'Point', '-6.83790', '33.93353');
INSERT INTO `shops` VALUES ('5a0c6789fd3eb67969316cd6', 'http://placehold.it/150x150', 'Frosnex', 'leilaware@frosnex.com', 'Rabat', 'Point', '-6.76316', '33.86427');
INSERT INTO `shops` VALUES ('5a0c6789fd3eb67969316cd7', 'http://placehold.it/150x150', 'Polarax', 'leilaware@polarax.com', 'Rabat', 'Point', '-6.77299', '33.95444');
INSERT INTO `shops` VALUES ('5a0c6789fd3eb67969316cd8', 'http://placehold.it/150x150', 'Cujo', 'leilaware@cujo.com', 'Rabat', 'Point', '-6.83668', '33.90277');
INSERT INTO `shops` VALUES ('5a0c6789fd3eb67969316cd9', 'http://placehold.it/150x150', 'Homelux', 'leilaware@homelux.com', 'Rabat', 'Point', '-6.82306', '33.90954');
INSERT INTO `shops` VALUES ('5a0c6789fd3eb67969316cda', 'http://placehold.it/150x150', 'Corecom', 'leilaware@corecom.com', 'Rabat', 'Point', '-6.80748', '33.82309');
INSERT INTO `shops` VALUES ('5a0c6797fd3eb67969316cdb', 'http://placehold.it/150x150', 'Aquazure', 'leilaware@aquazure.com', 'Rabat', 'Point', '-6.82145', '33.81120');
INSERT INTO `shops` VALUES ('5a0c6797fd3eb67969316cdc', 'http://placehold.it/150x150', 'Bovis', 'leilaware@bovis.com', 'Rabat', 'Point', '-6.84044', '33.81200');
INSERT INTO `shops` VALUES ('5a0c6797fd3eb67969316cdd', 'http://placehold.it/150x150', 'Nixelt', 'leilaware@nixelt.com', 'Rabat', 'Point', '-6.77840', '33.80491');
INSERT INTO `shops` VALUES ('5a0c6797fd3eb67969316cde', 'http://placehold.it/150x150', 'Combot', 'leilaware@combot.com', 'Rabat', 'Point', '-6.78045', '33.88310');
INSERT INTO `shops` VALUES ('5a0c6797fd3eb67969316cdf', 'http://placehold.it/150x150', 'Radiantix', 'leilaware@radiantix.com', 'Rabat', 'Point', '-6.75229', '33.95034');
INSERT INTO `shops` VALUES ('5a0c6797fd3eb67969316ce0', 'http://placehold.it/150x150', 'Musaphics', 'leilaware@musaphics.com', 'Rabat', 'Point', '-6.76087', '33.92329');
INSERT INTO `shops` VALUES ('5a0c6797fd3eb67969316ce1', 'http://placehold.it/150x150', 'Zentury', 'leilaware@zentury.com', 'Rabat', 'Point', '-6.75854', '33.87839');
INSERT INTO `shops` VALUES ('5a0c6797fd3eb67969316ce2', 'http://placehold.it/150x150', 'Genmom', 'leilaware@genmom.com', 'Rabat', 'Point', '-6.79387', '33.83957');
INSERT INTO `shops` VALUES ('5a0c6797fd3eb67969316ce3', 'http://placehold.it/150x150', 'Dymi', 'leilaware@dymi.com', 'Rabat', 'Point', '-6.84418', '33.85318');
INSERT INTO `shops` VALUES ('5a0c6797fd3eb67969316ce4', 'http://placehold.it/150x150', 'Exoswitch', 'leilaware@exoswitch.com', 'Rabat', 'Point', '-6.74934', '33.82365');
INSERT INTO `shops` VALUES ('5a0c6797fd3eb67969316ce5', 'http://placehold.it/150x150', 'Verbus', 'leilaware@verbus.com', 'Rabat', 'Point', '-6.83603', '33.89594');
INSERT INTO `shops` VALUES ('5a0c6797fd3eb67969316ce6', 'http://placehold.it/150x150', 'Inquala', 'leilaware@inquala.com', 'Rabat', 'Point', '-6.84380', '33.84340');
INSERT INTO `shops` VALUES ('5a0c6797fd3eb67969316ce7', 'http://placehold.it/150x150', 'Fangold', 'leilaware@fangold.com', 'Rabat', 'Point', '-6.83297', '33.96749');
INSERT INTO `shops` VALUES ('5a0c6797fd3eb67969316ce8', 'http://placehold.it/150x150', 'Lotron', 'leilaware@lotron.com', 'Rabat', 'Point', '-6.81209', '33.87673');
INSERT INTO `shops` VALUES ('5a0c67cafd3eb67969316ce9', 'http://placehold.it/150x150', 'Gronk', 'leilaware@gronk.com', 'Rabat', 'Point', '-6.83079', '33.97220');
INSERT INTO `shops` VALUES ('5a0c67cafd3eb67969316cea', 'http://placehold.it/150x150', 'Snorus', 'leilaware@snorus.com', 'Rabat', 'Point', '-6.84665', '33.86180');
INSERT INTO `shops` VALUES ('5a0c67cafd3eb67969316ceb', 'http://placehold.it/150x150', 'Musaphics', 'leilaware@musaphics.com', 'Rabat', 'Point', '-6.78246', '33.91788');
INSERT INTO `shops` VALUES ('5a0c67cafd3eb67969316cec', 'http://placehold.it/150x150', 'Zolavo', 'leilaware@zolavo.com', 'Rabat', 'Point', '-6.83010', '33.82438');
INSERT INTO `shops` VALUES ('5a0c67cafd3eb67969316ced', 'http://placehold.it/150x150', 'Orbean', 'leilaware@orbean.com', 'Rabat', 'Point', '-6.83871', '33.80629');
INSERT INTO `shops` VALUES ('5a0c67cafd3eb67969316cee', 'http://placehold.it/150x150', 'Scentric', 'leilaware@scentric.com', 'Rabat', 'Point', '-6.83326', '33.96551');
INSERT INTO `shops` VALUES ('5a0c67cafd3eb67969316cef', 'http://placehold.it/150x150', 'Zorromop', 'leilaware@zorromop.com', 'Rabat', 'Point', '-6.83456', '33.93267');
INSERT INTO `shops` VALUES ('5a0c67cafd3eb67969316cf0', 'http://placehold.it/150x150', 'Empirica', 'leilaware@empirica.com', 'Rabat', 'Point', '-6.79357', '33.99090');
INSERT INTO `shops` VALUES ('5a0c67cafd3eb67969316cf1', 'http://placehold.it/150x150', 'Terragen', 'leilaware@terragen.com', 'Rabat', 'Point', '-6.79704', '33.81158');
INSERT INTO `shops` VALUES ('5a0c67cafd3eb67969316cf2', 'http://placehold.it/150x150', 'Zaggles', 'leilaware@zaggles.com', 'Rabat', 'Point', '-6.79283', '33.80759');
INSERT INTO `shops` VALUES ('5a0c67cafd3eb67969316cf3', 'http://placehold.it/150x150', 'Furnafix', 'leilaware@furnafix.com', 'Rabat', 'Point', '-6.82956', '33.91959');
INSERT INTO `shops` VALUES ('5a0c67cafd3eb67969316cf4', 'http://placehold.it/150x150', 'Quilch', 'leilaware@quilch.com', 'Rabat', 'Point', '-6.80042', '33.87388');
INSERT INTO `shops` VALUES ('5a0c67cafd3eb67969316cf5', 'http://placehold.it/150x150', 'Zentime', 'leilaware@zentime.com', 'Rabat', 'Point', '-6.81954', '33.85590');
INSERT INTO `shops` VALUES ('5a0c67cafd3eb67969316cf6', 'http://placehold.it/150x150', 'Irack', 'leilaware@irack.com', 'Rabat', 'Point', '-6.79309', '33.98909');
INSERT INTO `shops` VALUES ('5a0c67e9fd3eb67969316cf7', 'http://placehold.it/150x150', 'Multron', 'leilaware@multron.com', 'Rabat', 'Point', '-6.80932', '33.97945');
INSERT INTO `shops` VALUES ('5a0c67e9fd3eb67969316cf8', 'http://placehold.it/150x150', 'Soprano', 'leilaware@soprano.com', 'Rabat', 'Point', '-6.75435', '33.83201');
INSERT INTO `shops` VALUES ('5a0c67e9fd3eb67969316cf9', 'http://placehold.it/150x150', 'Kneedles', 'leilaware@kneedles.com', 'Rabat', 'Point', '-6.78704', '33.90884');
INSERT INTO `shops` VALUES ('5a0c67e9fd3eb67969316cfa', 'http://placehold.it/150x150', 'Inear', 'leilaware@inear.com', 'Rabat', 'Point', '-6.79758', '33.81992');
INSERT INTO `shops` VALUES ('5a0c67e9fd3eb67969316cfb', 'http://placehold.it/150x150', 'Zenco', 'leilaware@zenco.com', 'Rabat', 'Point', '-6.82355', '33.93512');
INSERT INTO `shops` VALUES ('5a0c67e9fd3eb67969316cfc', 'http://placehold.it/150x150', 'Extragene', 'leilaware@extragene.com', 'Rabat', 'Point', '-6.83153', '33.81330');
INSERT INTO `shops` VALUES ('5a0c67e9fd3eb67969316cfd', 'http://placehold.it/150x150', 'Megall', 'leilaware@megall.com', 'Rabat', 'Point', '-6.83357', '33.93788');
INSERT INTO `shops` VALUES ('5a0c67e9fd3eb67969316cfe', 'http://placehold.it/150x150', 'Klugger', 'leilaware@klugger.com', 'Rabat', 'Point', '-6.79661', '33.90053');
INSERT INTO `shops` VALUES ('5a0c67e9fd3eb67969316cff', 'http://placehold.it/150x150', 'Zipak', 'leilaware@zipak.com', 'Rabat', 'Point', '-6.74736', '33.81514');
INSERT INTO `shops` VALUES ('5a0c67e9fd3eb67969316d00', 'http://placehold.it/150x150', 'Quotezart', 'leilaware@quotezart.com', 'Rabat', 'Point', '-6.78849', '33.99337');
INSERT INTO `shops` VALUES ('5a0c67e9fd3eb67969316d01', 'http://placehold.it/150x150', 'Imaginart', 'leilaware@imaginart.com', 'Rabat', 'Point', '-6.81157', '33.99564');
INSERT INTO `shops` VALUES ('5a0c67e9fd3eb67969316d02', 'http://placehold.it/150x150', 'Zenolux', 'leilaware@zenolux.com', 'Rabat', 'Point', '-6.76269', '33.83833');
INSERT INTO `shops` VALUES ('5a0c67e9fd3eb67969316d03', 'http://placehold.it/150x150', 'Newcube', 'leilaware@newcube.com', 'Rabat', 'Point', '-6.83287', '33.96337');
INSERT INTO `shops` VALUES ('5a0c67e9fd3eb67969316d04', 'http://placehold.it/150x150', 'Isodrive', 'leilaware@isodrive.com', 'Rabat', 'Point', '-6.84503', '33.91952');
INSERT INTO `shops` VALUES ('5a0c67e9fd3eb67969316d05', 'http://placehold.it/150x150', 'Geekosis', 'leilaware@geekosis.com', 'Rabat', 'Point', '-6.81826', '33.84792');
INSERT INTO `shops` VALUES ('5a0c67e9fd3eb67969316d06', 'http://placehold.it/150x150', 'Diginetic', 'leilaware@diginetic.com', 'Rabat', 'Point', '-6.84502', '33.92325');
INSERT INTO `shops` VALUES ('5a0c67e9fd3eb67969316d07', 'http://placehold.it/150x150', 'Ultrimax', 'leilaware@ultrimax.com', 'Rabat', 'Point', '-6.75473', '33.84333');
INSERT INTO `shops` VALUES ('5a0c680afd3eb67969316d08', 'http://placehold.it/150x150', 'Valreda', 'leilaware@valreda.com', 'Rabat', 'Point', '-6.83789', '33.86515');
INSERT INTO `shops` VALUES ('5a0c680afd3eb67969316d09', 'http://placehold.it/150x150', 'Recritube', 'leilaware@recritube.com', 'Rabat', 'Point', '-6.78916', '33.87576');
INSERT INTO `shops` VALUES ('5a0c680afd3eb67969316d0a', 'http://placehold.it/150x150', 'Datagen', 'leilaware@datagen.com', 'Rabat', 'Point', '-6.83263', '33.91399');
INSERT INTO `shops` VALUES ('5a0c680afd3eb67969316d0b', 'http://placehold.it/150x150', 'Animalia', 'leilaware@animalia.com', 'Rabat', 'Point', '-6.74830', '33.86793');
INSERT INTO `shops` VALUES ('5a0c680afd3eb67969316d0c', 'http://placehold.it/150x150', 'Limage', 'leilaware@limage.com', 'Rabat', 'Point', '-6.84039', '33.97518');
INSERT INTO `shops` VALUES ('5a0c680afd3eb67969316d0d', 'http://placehold.it/150x150', 'Zanilla', 'leilaware@zanilla.com', 'Rabat', 'Point', '-6.79739', '33.80084');
INSERT INTO `shops` VALUES ('5a0c680afd3eb67969316d0e', 'http://placehold.it/150x150', 'Proflex', 'leilaware@proflex.com', 'Rabat', 'Point', '-6.82649', '33.80586');
INSERT INTO `shops` VALUES ('5a0c680afd3eb67969316d0f', 'http://placehold.it/150x150', 'Firewax', 'leilaware@firewax.com', 'Rabat', 'Point', '-6.76472', '33.96184');
INSERT INTO `shops` VALUES ('5a0c680afd3eb67969316d10', 'http://placehold.it/150x150', 'Multiflex', 'leilaware@multiflex.com', 'Rabat', 'Point', '-6.78845', '33.96487');
INSERT INTO `shops` VALUES ('5a0c680afd3eb67969316d11', 'http://placehold.it/150x150', 'Colaire', 'leilaware@colaire.com', 'Rabat', 'Point', '-6.84288', '33.91697');
INSERT INTO `shops` VALUES ('5a0c680afd3eb67969316d12', 'http://placehold.it/150x150', 'Cinesanct', 'leilaware@cinesanct.com', 'Rabat', 'Point', '-6.82376', '33.90647');
INSERT INTO `shops` VALUES ('5a0c680afd3eb67969316d13', 'http://placehold.it/150x150', 'Illumity', 'leilaware@illumity.com', 'Rabat', 'Point', '-6.77704', '33.84155');
INSERT INTO `shops` VALUES ('5a0c680afd3eb67969316d14', 'http://placehold.it/150x150', 'Futuris', 'leilaware@futuris.com', 'Rabat', 'Point', '-6.74868', '33.84807');
INSERT INTO `shops` VALUES ('5a0c680afd3eb67969316d15', 'http://placehold.it/150x150', 'Mediot', 'leilaware@mediot.com', 'Rabat', 'Point', '-6.80163', '33.87195');
INSERT INTO `shops` VALUES ('5a0c680afd3eb67969316d16', 'http://placehold.it/150x150', 'Corporana', 'leilaware@corporana.com', 'Rabat', 'Point', '-6.77783', '33.84444');
INSERT INTO `shops` VALUES ('5a0c680afd3eb67969316d17', 'http://placehold.it/150x150', 'Intergeek', 'leilaware@intergeek.com', 'Rabat', 'Point', '-6.83708', '33.94228');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d18', 'http://placehold.it/150x150', 'Quordate', 'leilaware@quordate.com', 'Rabat', 'Point', '-6.79025', '33.88059');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d19', 'http://placehold.it/150x150', 'Anarco', 'leilaware@anarco.com', 'Rabat', 'Point', '-6.76527', '33.94852');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d1a', 'http://placehold.it/150x150', 'Medalert', 'leilaware@medalert.com', 'Rabat', 'Point', '-6.83038', '33.81058');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d1b', 'http://placehold.it/150x150', 'Gonkle', 'leilaware@gonkle.com', 'Rabat', 'Point', '-6.76673', '33.84282');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d1c', 'http://placehold.it/150x150', 'Callflex', 'leilaware@callflex.com', 'Rabat', 'Point', '-6.84022', '33.96167');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d1d', 'http://placehold.it/150x150', 'Terascape', 'leilaware@terascape.com', 'Rabat', 'Point', '-6.82571', '33.86166');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d1e', 'http://placehold.it/150x150', 'Zilencio', 'leilaware@zilencio.com', 'Rabat', 'Point', '-6.77078', '33.92877');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d1f', 'http://placehold.it/150x150', 'Digiprint', 'leilaware@digiprint.com', 'Rabat', 'Point', '-6.82542', '33.85383');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d20', 'http://placehold.it/150x150', 'Navir', 'leilaware@navir.com', 'Rabat', 'Point', '-6.83166', '33.93683');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d21', 'http://placehold.it/150x150', 'Capscreen', 'leilaware@capscreen.com', 'Rabat', 'Point', '-6.76421', '33.89753');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d22', 'http://placehold.it/150x150', 'Bezal', 'leilaware@bezal.com', 'Rabat', 'Point', '-6.79756', '33.92858');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d23', 'http://placehold.it/150x150', 'Insurety', 'leilaware@insurety.com', 'Rabat', 'Point', '-6.84015', '33.97918');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d24', 'http://placehold.it/150x150', 'Deminimum', 'leilaware@deminimum.com', 'Rabat', 'Point', '-6.81579', '33.80807');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d25', 'http://placehold.it/150x150', 'Insectus', 'leilaware@insectus.com', 'Rabat', 'Point', '-6.77309', '33.90475');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d26', 'http://placehold.it/150x150', 'Slambda', 'leilaware@slambda.com', 'Rabat', 'Point', '-6.82149', '33.92087');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d27', 'http://placehold.it/150x150', 'Bisba', 'leilaware@bisba.com', 'Rabat', 'Point', '-6.79137', '33.84051');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d28', 'http://placehold.it/150x150', 'Zoarere', 'leilaware@zoarere.com', 'Rabat', 'Point', '-6.76169', '33.96976');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d29', 'http://placehold.it/150x150', 'Rubadub', 'leilaware@rubadub.com', 'Rabat', 'Point', '-6.75018', '33.92082');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d2a', 'http://placehold.it/150x150', 'Fitcore', 'leilaware@fitcore.com', 'Rabat', 'Point', '-6.81239', '33.83750');
INSERT INTO `shops` VALUES ('5a0c6817fd3eb67969316d2b', 'http://placehold.it/150x150', 'Mixers', 'leilaware@mixers.com', 'Rabat', 'Point', '-6.84393', '33.99179');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d2c', 'http://placehold.it/150x150', 'Exozent', 'leilaware@exozent.com', 'Rabat', 'Point', '-6.79665', '33.90796');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d2d', 'http://placehold.it/150x150', 'Koffee', 'leilaware@koffee.com', 'Rabat', 'Point', '-6.80304', '33.93513');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d2e', 'http://placehold.it/150x150', 'Repetwire', 'leilaware@repetwire.com', 'Rabat', 'Point', '-6.77950', '33.93867');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d2f', 'http://placehold.it/150x150', 'Grupoli', 'leilaware@grupoli.com', 'Rabat', 'Point', '-6.82952', '33.86433');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d30', 'http://placehold.it/150x150', 'Comtrail', 'leilaware@comtrail.com', 'Rabat', 'Point', '-6.83662', '33.92165');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d31', 'http://placehold.it/150x150', 'Pasturia', 'leilaware@pasturia.com', 'Rabat', 'Point', '-6.77770', '33.97911');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d32', 'http://placehold.it/150x150', 'Mangelica', 'leilaware@mangelica.com', 'Rabat', 'Point', '-6.83451', '33.85529');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d33', 'http://placehold.it/150x150', 'Delphide', 'leilaware@delphide.com', 'Rabat', 'Point', '-6.78017', '33.90750');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d34', 'http://placehold.it/150x150', 'Franscene', 'leilaware@franscene.com', 'Rabat', 'Point', '-6.75700', '33.85657');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d35', 'http://placehold.it/150x150', 'Comtest', 'leilaware@comtest.com', 'Rabat', 'Point', '-6.77214', '33.98496');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d36', 'http://placehold.it/150x150', 'Krag', 'leilaware@krag.com', 'Rabat', 'Point', '-6.79633', '33.83348');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d37', 'http://placehold.it/150x150', 'Isotronic', 'leilaware@isotronic.com', 'Rabat', 'Point', '-6.79018', '33.86291');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d38', 'http://placehold.it/150x150', 'Sultrax', 'leilaware@sultrax.com', 'Rabat', 'Point', '-6.79318', '33.92908');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d39', 'http://placehold.it/150x150', 'Veraq', 'leilaware@veraq.com', 'Rabat', 'Point', '-6.76394', '33.88376');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d3a', 'http://placehold.it/150x150', 'Plasmos', 'leilaware@plasmos.com', 'Rabat', 'Point', '-6.79591', '33.83437');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d3b', 'http://placehold.it/150x150', 'Comstruct', 'leilaware@comstruct.com', 'Rabat', 'Point', '-6.81188', '33.83033');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d3c', 'http://placehold.it/150x150', 'Isosphere', 'leilaware@isosphere.com', 'Rabat', 'Point', '-6.82254', '33.80692');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d3d', 'http://placehold.it/150x150', 'Diginetic', 'leilaware@diginetic.com', 'Rabat', 'Point', '-6.77412', '33.94772');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d3e', 'http://placehold.it/150x150', 'Digiprint', 'leilaware@digiprint.com', 'Rabat', 'Point', '-6.82925', '33.91411');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d3f', 'http://placehold.it/150x150', 'Zaj', 'leilaware@zaj.com', 'Rabat', 'Point', '-6.80406', '33.90230');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d40', 'http://placehold.it/150x150', 'Bluplanet', 'leilaware@bluplanet.com', 'Rabat', 'Point', '-6.78665', '33.97746');
INSERT INTO `shops` VALUES ('5a0c687dfd3eb67969316d41', 'http://placehold.it/150x150', 'Zizzle', 'leilaware@zizzle.com', 'Rabat', 'Point', '-6.84065', '33.96044');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d42', 'http://placehold.it/150x150', 'Viasia', 'leilaware@viasia.com', 'Rabat', 'Point', '-6.78266', '33.85260');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d43', 'http://placehold.it/150x150', 'Skyplex', 'leilaware@skyplex.com', 'Rabat', 'Point', '-6.83191', '33.95952');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d44', 'http://placehold.it/150x150', 'Capscreen', 'leilaware@capscreen.com', 'Rabat', 'Point', '-6.83952', '33.90985');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d45', 'http://placehold.it/150x150', 'Zaya', 'leilaware@zaya.com', 'Rabat', 'Point', '-6.81268', '33.91896');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d46', 'http://placehold.it/150x150', 'Elpro', 'leilaware@elpro.com', 'Rabat', 'Point', '-6.75786', '33.86421');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d47', 'http://placehold.it/150x150', 'Ovium', 'leilaware@ovium.com', 'Rabat', 'Point', '-6.83239', '33.97846');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d48', 'http://placehold.it/150x150', 'Sportan', 'leilaware@sportan.com', 'Rabat', 'Point', '-6.78146', '33.80955');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d49', 'http://placehold.it/150x150', 'Imaginart', 'leilaware@imaginart.com', 'Rabat', 'Point', '-6.83928', '33.80205');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d4a', 'http://placehold.it/150x150', 'Otherway', 'leilaware@otherway.com', 'Rabat', 'Point', '-6.81730', '33.89579');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d4b', 'http://placehold.it/150x150', 'Nitracyr', 'leilaware@nitracyr.com', 'Rabat', 'Point', '-6.75817', '33.90178');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d4c', 'http://placehold.it/150x150', 'Flyboyz', 'leilaware@flyboyz.com', 'Rabat', 'Point', '-6.84326', '33.84391');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d4d', 'http://placehold.it/150x150', 'Ultrasure', 'leilaware@ultrasure.com', 'Rabat', 'Point', '-6.77748', '33.84626');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d4e', 'http://placehold.it/150x150', 'Geekular', 'leilaware@geekular.com', 'Rabat', 'Point', '-6.74840', '33.84443');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d4f', 'http://placehold.it/150x150', 'Bedlam', 'leilaware@bedlam.com', 'Rabat', 'Point', '-6.79630', '33.81976');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d50', 'http://placehold.it/150x150', 'Speedbolt', 'leilaware@speedbolt.com', 'Rabat', 'Point', '-6.77091', '33.86472');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d51', 'http://placehold.it/150x150', 'Zaggles', 'leilaware@zaggles.com', 'Rabat', 'Point', '-6.77643', '33.90772');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d52', 'http://placehold.it/150x150', 'Anixang', 'leilaware@anixang.com', 'Rabat', 'Point', '-6.81077', '33.89655');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d53', 'http://placehold.it/150x150', 'Gonkle', 'leilaware@gonkle.com', 'Rabat', 'Point', '-6.79612', '33.84739');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d54', 'http://placehold.it/150x150', 'Besto', 'leilaware@besto.com', 'Rabat', 'Point', '-6.83368', '33.95549');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d55', 'http://placehold.it/150x150', 'Nipaz', 'leilaware@nipaz.com', 'Rabat', 'Point', '-6.77913', '33.98259');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d56', 'http://placehold.it/150x150', 'Tropoli', 'leilaware@tropoli.com', 'Rabat', 'Point', '-6.75627', '33.87953');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d57', 'http://placehold.it/150x150', 'Quilch', 'leilaware@quilch.com', 'Rabat', 'Point', '-6.81153', '33.96788');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d58', 'http://placehold.it/150x150', 'Waretel', 'leilaware@waretel.com', 'Rabat', 'Point', '-6.78895', '33.97824');
INSERT INTO `shops` VALUES ('5a0c689efd3eb67969316d59', 'http://placehold.it/150x150', 'Senmao', 'leilaware@senmao.com', 'Rabat', 'Point', '-6.79473', '33.85730');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d5a', 'http://placehold.it/150x150', 'Datacator', 'leilaware@datacator.com', 'Rabat', 'Point', '-6.78270', '33.95476');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d5b', 'http://placehold.it/150x150', 'Zensure', 'leilaware@zensure.com', 'Rabat', 'Point', '-6.80316', '33.94916');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d5c', 'http://placehold.it/150x150', 'Zillidium', 'leilaware@zillidium.com', 'Rabat', 'Point', '-6.80883', '33.96045');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d5d', 'http://placehold.it/150x150', 'Apextri', 'leilaware@apextri.com', 'Rabat', 'Point', '-6.79806', '33.90886');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d5e', 'http://placehold.it/150x150', 'Bittor', 'leilaware@bittor.com', 'Rabat', 'Point', '-6.82572', '33.86219');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d5f', 'http://placehold.it/150x150', 'Elemantra', 'leilaware@elemantra.com', 'Rabat', 'Point', '-6.80786', '33.87471');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d60', 'http://placehold.it/150x150', 'Panzent', 'leilaware@panzent.com', 'Rabat', 'Point', '-6.82365', '33.84756');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d61', 'http://placehold.it/150x150', 'Inear', 'leilaware@inear.com', 'Rabat', 'Point', '-6.75358', '33.91787');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d62', 'http://placehold.it/150x150', 'Rockabye', 'leilaware@rockabye.com', 'Rabat', 'Point', '-6.74976', '33.91279');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d63', 'http://placehold.it/150x150', 'Dadabase', 'leilaware@dadabase.com', 'Rabat', 'Point', '-6.80423', '33.86394');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d64', 'http://placehold.it/150x150', 'Everest', 'leilaware@everest.com', 'Rabat', 'Point', '-6.77520', '33.85257');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d65', 'http://placehold.it/150x150', 'Colaire', 'leilaware@colaire.com', 'Rabat', 'Point', '-6.84071', '33.92175');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d66', 'http://placehold.it/150x150', 'Comcur', 'leilaware@comcur.com', 'Rabat', 'Point', '-6.80501', '33.96619');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d67', 'http://placehold.it/150x150', 'Pholio', 'leilaware@pholio.com', 'Rabat', 'Point', '-6.83499', '33.94669');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d68', 'http://placehold.it/150x150', 'Datagen', 'leilaware@datagen.com', 'Rabat', 'Point', '-6.76886', '33.97208');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d69', 'http://placehold.it/150x150', 'Progenex', 'leilaware@progenex.com', 'Rabat', 'Point', '-6.78666', '33.86607');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d6a', 'http://placehold.it/150x150', 'Nixelt', 'leilaware@nixelt.com', 'Rabat', 'Point', '-6.78839', '33.82126');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d6b', 'http://placehold.it/150x150', 'Kozgene', 'leilaware@kozgene.com', 'Rabat', 'Point', '-6.75328', '33.84881');
INSERT INTO `shops` VALUES ('5a0c6b1dfd3eb67969316d6c', 'http://placehold.it/150x150', 'Buzzness', 'leilaware@buzzness.com', 'Rabat', 'Point', '-6.84414', '33.93806');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d6d', 'http://placehold.it/150x150', 'Mondicil', 'leilaware@mondicil.com', 'Rabat', 'Point', '-6.74722', '33.85523');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d6e', 'http://placehold.it/150x150', 'Filodyne', 'leilaware@filodyne.com', 'Rabat', 'Point', '-6.74700', '33.98196');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d6f', 'http://placehold.it/150x150', 'Sultrax', 'leilaware@sultrax.com', 'Rabat', 'Point', '-6.77017', '33.84833');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d70', 'http://placehold.it/150x150', 'Orbixtar', 'leilaware@orbixtar.com', 'Rabat', 'Point', '-6.75851', '33.90786');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d71', 'http://placehold.it/150x150', 'Injoy', 'leilaware@injoy.com', 'Rabat', 'Point', '-6.76261', '33.83654');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d72', 'http://placehold.it/150x150', 'Corporana', 'leilaware@corporana.com', 'Rabat', 'Point', '-6.78686', '33.97273');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d73', 'http://placehold.it/150x150', 'Trollery', 'leilaware@trollery.com', 'Rabat', 'Point', '-6.84009', '33.94218');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d74', 'http://placehold.it/150x150', 'Suretech', 'leilaware@suretech.com', 'Rabat', 'Point', '-6.75684', '33.92775');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d75', 'http://placehold.it/150x150', 'Medicroix', 'leilaware@medicroix.com', 'Rabat', 'Point', '-6.81207', '33.96851');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d76', 'http://placehold.it/150x150', 'Zilidium', 'leilaware@zilidium.com', 'Rabat', 'Point', '-6.80404', '33.88483');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d77', 'http://placehold.it/150x150', 'Evidends', 'leilaware@evidends.com', 'Rabat', 'Point', '-6.78372', '33.93306');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d78', 'http://placehold.it/150x150', 'Obones', 'leilaware@obones.com', 'Rabat', 'Point', '-6.75019', '33.89847');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d79', 'http://placehold.it/150x150', 'Bovis', 'leilaware@bovis.com', 'Rabat', 'Point', '-6.81018', '33.98705');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d7a', 'http://placehold.it/150x150', 'Vitricomp', 'leilaware@vitricomp.com', 'Rabat', 'Point', '-6.77941', '33.89834');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d7b', 'http://placehold.it/150x150', 'Apextri', 'leilaware@apextri.com', 'Rabat', 'Point', '-6.75586', '33.94091');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d7c', 'http://placehold.it/150x150', 'Tropoli', 'leilaware@tropoli.com', 'Rabat', 'Point', '-6.83355', '33.98069');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d7d', 'http://placehold.it/150x150', 'Comvoy', 'leilaware@comvoy.com', 'Rabat', 'Point', '-6.79748', '33.83104');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d7e', 'http://placehold.it/150x150', 'Eyeris', 'leilaware@eyeris.com', 'Rabat', 'Point', '-6.79578', '33.98654');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d7f', 'http://placehold.it/150x150', 'Genesynk', 'leilaware@genesynk.com', 'Rabat', 'Point', '-6.78956', '33.93169');
INSERT INTO `shops` VALUES ('5a0c6b2dfd3eb67969316d80', 'http://placehold.it/150x150', 'Hydrocom', 'leilaware@hydrocom.com', 'Rabat', 'Point', '-6.80956', '33.82815');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d81', 'http://placehold.it/150x150', 'Mondicil', 'leilaware@mondicil.com', 'Rabat', 'Point', '-6.74722', '33.85523');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d82', 'http://placehold.it/150x150', 'Filodyne', 'leilaware@filodyne.com', 'Rabat', 'Point', '-6.74700', '33.98196');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d83', 'http://placehold.it/150x150', 'Sultrax', 'leilaware@sultrax.com', 'Rabat', 'Point', '-6.77017', '33.84833');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d84', 'http://placehold.it/150x150', 'Orbixtar', 'leilaware@orbixtar.com', 'Rabat', 'Point', '-6.75851', '33.90786');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d85', 'http://placehold.it/150x150', 'Injoy', 'leilaware@injoy.com', 'Rabat', 'Point', '-6.76261', '33.83654');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d86', 'http://placehold.it/150x150', 'Corporana', 'leilaware@corporana.com', 'Rabat', 'Point', '-6.78686', '33.97273');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d87', 'http://placehold.it/150x150', 'Trollery', 'leilaware@trollery.com', 'Rabat', 'Point', '-6.84009', '33.94218');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d88', 'http://placehold.it/150x150', 'Suretech', 'leilaware@suretech.com', 'Rabat', 'Point', '-6.75684', '33.92775');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d89', 'http://placehold.it/150x150', 'Medicroix', 'leilaware@medicroix.com', 'Rabat', 'Point', '-6.81207', '33.96851');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d8a', 'http://placehold.it/150x150', 'Zilidium', 'leilaware@zilidium.com', 'Rabat', 'Point', '-6.80404', '33.88483');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d8b', 'http://placehold.it/150x150', 'Evidends', 'leilaware@evidends.com', 'Rabat', 'Point', '-6.78372', '33.93306');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d8c', 'http://placehold.it/150x150', 'Obones', 'leilaware@obones.com', 'Rabat', 'Point', '-6.75019', '33.89847');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d8d', 'http://placehold.it/150x150', 'Bovis', 'leilaware@bovis.com', 'Rabat', 'Point', '-6.81018', '33.98705');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d8e', 'http://placehold.it/150x150', 'Vitricomp', 'leilaware@vitricomp.com', 'Rabat', 'Point', '-6.77941', '33.89834');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d8f', 'http://placehold.it/150x150', 'Apextri', 'leilaware@apextri.com', 'Rabat', 'Point', '-6.75586', '33.94091');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d90', 'http://placehold.it/150x150', 'Tropoli', 'leilaware@tropoli.com', 'Rabat', 'Point', '-6.83355', '33.98069');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d91', 'http://placehold.it/150x150', 'Comvoy', 'leilaware@comvoy.com', 'Rabat', 'Point', '-6.79748', '33.83104');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d92', 'http://placehold.it/150x150', 'Eyeris', 'leilaware@eyeris.com', 'Rabat', 'Point', '-6.79578', '33.98654');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d93', 'http://placehold.it/150x150', 'Genesynk', 'leilaware@genesynk.com', 'Rabat', 'Point', '-6.78956', '33.93169');
INSERT INTO `shops` VALUES ('5a0c6b42fd3eb67969316d94', 'http://placehold.it/150x150', 'Hydrocom', 'leilaware@hydrocom.com', 'Rabat', 'Point', '-6.80956', '33.82815');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316d95', 'http://placehold.it/150x150', 'Kage', 'leilaware@kage.com', 'Rabat', 'Point', '-6.81832', '33.95645');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316d96', 'http://placehold.it/150x150', 'Zedalis', 'leilaware@zedalis.com', 'Rabat', 'Point', '-6.80287', '33.95750');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316d97', 'http://placehold.it/150x150', 'Zillan', 'leilaware@zillan.com', 'Rabat', 'Point', '-6.77143', '33.93771');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316d98', 'http://placehold.it/150x150', 'Vurbo', 'leilaware@vurbo.com', 'Rabat', 'Point', '-6.80835', '33.85408');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316d99', 'http://placehold.it/150x150', 'Magnemo', 'leilaware@magnemo.com', 'Rabat', 'Point', '-6.75796', '33.90401');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316d9a', 'http://placehold.it/150x150', 'Providco', 'leilaware@providco.com', 'Rabat', 'Point', '-6.82018', '33.96232');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316d9b', 'http://placehold.it/150x150', 'Tubalum', 'leilaware@tubalum.com', 'Rabat', 'Point', '-6.77033', '33.88405');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316d9c', 'http://placehold.it/150x150', 'Gynko', 'leilaware@gynko.com', 'Rabat', 'Point', '-6.76610', '33.86215');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316d9d', 'http://placehold.it/150x150', 'Genekom', 'leilaware@genekom.com', 'Rabat', 'Point', '-6.74695', '33.81594');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316d9e', 'http://placehold.it/150x150', 'Acium', 'leilaware@acium.com', 'Rabat', 'Point', '-6.81221', '33.94613');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316d9f', 'http://placehold.it/150x150', 'Talkalot', 'leilaware@talkalot.com', 'Rabat', 'Point', '-6.83579', '33.94983');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316da0', 'http://placehold.it/150x150', 'Illumity', 'leilaware@illumity.com', 'Rabat', 'Point', '-6.79319', '33.83036');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316da1', 'http://placehold.it/150x150', 'Acrodance', 'leilaware@acrodance.com', 'Rabat', 'Point', '-6.75917', '33.93589');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316da2', 'http://placehold.it/150x150', 'Powernet', 'leilaware@powernet.com', 'Rabat', 'Point', '-6.84276', '33.80035');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316da3', 'http://placehold.it/150x150', 'Pyramia', 'leilaware@pyramia.com', 'Rabat', 'Point', '-6.75301', '33.83085');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316da4', 'http://placehold.it/150x150', 'Corporana', 'leilaware@corporana.com', 'Rabat', 'Point', '-6.82863', '33.87765');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316da5', 'http://placehold.it/150x150', 'Isotronic', 'leilaware@isotronic.com', 'Rabat', 'Point', '-6.81091', '33.82032');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316da6', 'http://placehold.it/150x150', 'Menbrain', 'leilaware@menbrain.com', 'Rabat', 'Point', '-6.79439', '33.86054');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316da7', 'http://placehold.it/150x150', 'Aquacine', 'leilaware@aquacine.com', 'Rabat', 'Point', '-6.79010', '33.92195');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316da8', 'http://placehold.it/150x150', 'Geekko', 'leilaware@geekko.com', 'Rabat', 'Point', '-6.77585', '33.80125');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316da9', 'http://placehold.it/150x150', 'Netility', 'leilaware@netility.com', 'Rabat', 'Point', '-6.82861', '33.99216');
INSERT INTO `shops` VALUES ('5a0c6b55fd3eb67969316daa', 'http://placehold.it/150x150', 'Reversus', 'leilaware@reversus.com', 'Rabat', 'Point', '-6.74911', '33.91049');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316dab', 'http://placehold.it/150x150', 'Sureplex', 'leilaware@sureplex.com', 'Rabat', 'Point', '-6.75559', '33.95303');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316dac', 'http://placehold.it/150x150', 'Norali', 'leilaware@norali.com', 'Rabat', 'Point', '-6.75070', '33.92841');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316dad', 'http://placehold.it/150x150', 'Softmicro', 'leilaware@softmicro.com', 'Rabat', 'Point', '-6.83987', '33.90291');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316dae', 'http://placehold.it/150x150', 'Comcur', 'leilaware@comcur.com', 'Rabat', 'Point', '-6.79065', '33.81963');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316daf', 'http://placehold.it/150x150', 'Pyrami', 'leilaware@pyrami.com', 'Rabat', 'Point', '-6.76894', '33.83578');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316db0', 'http://placehold.it/150x150', 'Schoolio', 'leilaware@schoolio.com', 'Rabat', 'Point', '-6.76800', '33.81741');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316db1', 'http://placehold.it/150x150', 'Scenty', 'leilaware@scenty.com', 'Rabat', 'Point', '-6.78666', '33.91547');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316db2', 'http://placehold.it/150x150', 'Malathion', 'leilaware@malathion.com', 'Rabat', 'Point', '-6.75076', '33.86233');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316db3', 'http://placehold.it/150x150', 'Zboo', 'leilaware@zboo.com', 'Rabat', 'Point', '-6.78859', '33.98156');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316db4', 'http://placehold.it/150x150', 'Handshake', 'leilaware@handshake.com', 'Rabat', 'Point', '-6.84079', '33.95982');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316db5', 'http://placehold.it/150x150', 'Edecine', 'leilaware@edecine.com', 'Rabat', 'Point', '-6.77640', '33.86472');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316db6', 'http://placehold.it/150x150', 'Terragen', 'leilaware@terragen.com', 'Rabat', 'Point', '-6.77284', '33.93765');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316db7', 'http://placehold.it/150x150', 'Prowaste', 'leilaware@prowaste.com', 'Rabat', 'Point', '-6.79311', '33.99213');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316db8', 'http://placehold.it/150x150', 'Blurrybus', 'leilaware@blurrybus.com', 'Rabat', 'Point', '-6.83983', '33.92688');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316db9', 'http://placehold.it/150x150', 'Avit', 'leilaware@avit.com', 'Rabat', 'Point', '-6.81430', '33.84092');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316dba', 'http://placehold.it/150x150', 'Zentia', 'leilaware@zentia.com', 'Rabat', 'Point', '-6.84568', '33.94117');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316dbb', 'http://placehold.it/150x150', 'Xerex', 'leilaware@xerex.com', 'Rabat', 'Point', '-6.79398', '33.96065');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316dbc', 'http://placehold.it/150x150', 'Architax', 'leilaware@architax.com', 'Rabat', 'Point', '-6.81079', '33.95140');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316dbd', 'http://placehold.it/150x150', 'Wazzu', 'leilaware@wazzu.com', 'Rabat', 'Point', '-6.81948', '33.88568');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316dbe', 'http://placehold.it/150x150', 'Parleynet', 'leilaware@parleynet.com', 'Rabat', 'Point', '-6.79371', '33.80105');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316dbf', 'http://placehold.it/150x150', 'Talkola', 'leilaware@talkola.com', 'Rabat', 'Point', '-6.80291', '33.86063');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316dc0', 'http://placehold.it/150x150', 'Housedown', 'leilaware@housedown.com', 'Rabat', 'Point', '-6.79566', '33.94903');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316dc1', 'http://placehold.it/150x150', 'Ovium', 'leilaware@ovium.com', 'Rabat', 'Point', '-6.80660', '33.92018');
INSERT INTO `shops` VALUES ('5a0c6b61fd3eb67969316dc2', 'http://placehold.it/150x150', 'Reversus', 'leilaware@reversus.com', 'Rabat', 'Point', '-6.81053', '33.99545');
INSERT INTO `shops` VALUES ('5a0c6b75fd3eb67969316dc3', 'http://placehold.it/150x150', 'Kiosk', 'leilaware@kiosk.com', 'Rabat', 'Point', '-6.76816', '33.97174');
INSERT INTO `shops` VALUES ('5a0c6b75fd3eb67969316dc4', 'http://placehold.it/150x150', 'Unia', 'leilaware@unia.com', 'Rabat', 'Point', '-6.84483', '33.93537');
INSERT INTO `shops` VALUES ('5a0c6b75fd3eb67969316dc5', 'http://placehold.it/150x150', 'Aquasseur', 'leilaware@aquasseur.com', 'Rabat', 'Point', '-6.76921', '33.80830');
INSERT INTO `shops` VALUES ('5a0c6b75fd3eb67969316dc6', 'http://placehold.it/150x150', 'Duflex', 'leilaware@duflex.com', 'Rabat', 'Point', '-6.79208', '33.87378');
INSERT INTO `shops` VALUES ('5a0c6b75fd3eb67969316dc7', 'http://placehold.it/150x150', 'Zenolux', 'leilaware@zenolux.com', 'Rabat', 'Point', '-6.77611', '33.89991');
INSERT INTO `shops` VALUES ('5a0c6b75fd3eb67969316dc8', 'http://placehold.it/150x150', 'Voratak', 'leilaware@voratak.com', 'Rabat', 'Point', '-6.77635', '33.81809');
INSERT INTO `shops` VALUES ('5a0c6b75fd3eb67969316dc9', 'http://placehold.it/150x150', 'Canopoly', 'leilaware@canopoly.com', 'Rabat', 'Point', '-6.78195', '33.82580');
INSERT INTO `shops` VALUES ('5a0c6b75fd3eb67969316dca', 'http://placehold.it/150x150', 'Farmex', 'leilaware@farmex.com', 'Rabat', 'Point', '-6.77484', '33.92270');
INSERT INTO `shops` VALUES ('5a0c6b75fd3eb67969316dcb', 'http://placehold.it/150x150', 'Digiprint', 'leilaware@digiprint.com', 'Rabat', 'Point', '-6.80967', '33.94565');
INSERT INTO `shops` VALUES ('5a0c6b75fd3eb67969316dcc', 'http://placehold.it/150x150', 'Dentrex', 'leilaware@dentrex.com', 'Rabat', 'Point', '-6.82459', '33.95482');
INSERT INTO `shops` VALUES ('5a0c6b75fd3eb67969316dcd', 'http://placehold.it/150x150', 'Securia', 'leilaware@securia.com', 'Rabat', 'Point', '-6.80041', '33.90952');
INSERT INTO `shops` VALUES ('5a0c6b75fd3eb67969316dce', 'http://placehold.it/150x150', 'Ezent', 'leilaware@ezent.com', 'Rabat', 'Point', '-6.79328', '33.86559');
INSERT INTO `shops` VALUES ('5a0c6b75fd3eb67969316dcf', 'http://placehold.it/150x150', 'Microluxe', 'leilaware@microluxe.com', 'Rabat', 'Point', '-6.80882', '33.80990');
INSERT INTO `shops` VALUES ('5a0c6b75fd3eb67969316dd0', 'http://placehold.it/150x150', 'Rooforia', 'leilaware@rooforia.com', 'Rabat', 'Point', '-6.75874', '33.85044');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316dd1', 'http://placehold.it/150x150', 'Rugstars', 'leilaware@rugstars.com', 'Rabat', 'Point', '-6.82555', '33.90534');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316dd2', 'http://placehold.it/150x150', 'Futuris', 'leilaware@futuris.com', 'Rabat', 'Point', '-6.77191', '33.92781');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316dd3', 'http://placehold.it/150x150', 'Knowlysis', 'leilaware@knowlysis.com', 'Rabat', 'Point', '-6.78646', '33.86774');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316dd4', 'http://placehold.it/150x150', 'Sportan', 'leilaware@sportan.com', 'Rabat', 'Point', '-6.76351', '33.92313');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316dd5', 'http://placehold.it/150x150', 'Vendblend', 'leilaware@vendblend.com', 'Rabat', 'Point', '-6.76239', '33.81560');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316dd6', 'http://placehold.it/150x150', 'Gynko', 'leilaware@gynko.com', 'Rabat', 'Point', '-6.79011', '33.98307');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316dd7', 'http://placehold.it/150x150', 'Anivet', 'leilaware@anivet.com', 'Rabat', 'Point', '-6.75608', '33.96500');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316dd8', 'http://placehold.it/150x150', 'Emoltra', 'leilaware@emoltra.com', 'Rabat', 'Point', '-6.82551', '33.97388');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316dd9', 'http://placehold.it/150x150', 'Illumity', 'leilaware@illumity.com', 'Rabat', 'Point', '-6.78832', '33.96918');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316dda', 'http://placehold.it/150x150', 'Austech', 'leilaware@austech.com', 'Rabat', 'Point', '-6.84007', '33.92927');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316ddb', 'http://placehold.it/150x150', 'Boink', 'leilaware@boink.com', 'Rabat', 'Point', '-6.83766', '33.85683');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316ddc', 'http://placehold.it/150x150', 'Recritube', 'leilaware@recritube.com', 'Rabat', 'Point', '-6.77595', '33.86772');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316ddd', 'http://placehold.it/150x150', 'Comtrak', 'leilaware@comtrak.com', 'Rabat', 'Point', '-6.75099', '33.97885');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316dde', 'http://placehold.it/150x150', 'Vicon', 'leilaware@vicon.com', 'Rabat', 'Point', '-6.79196', '33.95231');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316ddf', 'http://placehold.it/150x150', 'Strezzo', 'leilaware@strezzo.com', 'Rabat', 'Point', '-6.76705', '33.94284');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316de0', 'http://placehold.it/150x150', 'Qimonk', 'leilaware@qimonk.com', 'Rabat', 'Point', '-6.79774', '33.83119');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316de1', 'http://placehold.it/150x150', 'Isonus', 'leilaware@isonus.com', 'Rabat', 'Point', '-6.76168', '33.80846');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316de2', 'http://placehold.it/150x150', 'Utarian', 'leilaware@utarian.com', 'Rabat', 'Point', '-6.78927', '33.96421');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316de3', 'http://placehold.it/150x150', 'Harmoney', 'leilaware@harmoney.com', 'Rabat', 'Point', '-6.81684', '33.92180');
INSERT INTO `shops` VALUES ('5a0c6b83fd3eb67969316de4', 'http://placehold.it/150x150', 'Isotrack', 'leilaware@isotrack.com', 'Rabat', 'Point', '-6.75823', '33.96455');
INSERT INTO `shops` VALUES ('5a0c6b90fd3eb67969316de5', 'http://placehold.it/150x150', 'Syntac', 'leilaware@syntac.com', 'Rabat', 'Point', '-6.84369', '33.99600');
INSERT INTO `shops` VALUES ('5a0c6b90fd3eb67969316de6', 'http://placehold.it/150x150', 'Marvane', 'leilaware@marvane.com', 'Rabat', 'Point', '-6.78614', '33.93422');
INSERT INTO `shops` VALUES ('5a0c6b90fd3eb67969316de7', 'http://placehold.it/150x150', 'Biotica', 'leilaware@biotica.com', 'Rabat', 'Point', '-6.83240', '33.80065');
INSERT INTO `shops` VALUES ('5a0c6b90fd3eb67969316de8', 'http://placehold.it/150x150', 'Apex', 'leilaware@apex.com', 'Rabat', 'Point', '-6.83740', '33.84035');
INSERT INTO `shops` VALUES ('5a0c6b90fd3eb67969316de9', 'http://placehold.it/150x150', 'Sustenza', 'leilaware@sustenza.com', 'Rabat', 'Point', '-6.81866', '33.80756');
INSERT INTO `shops` VALUES ('5a0c6b90fd3eb67969316dea', 'http://placehold.it/150x150', 'Dreamia', 'leilaware@dreamia.com', 'Rabat', 'Point', '-6.79713', '33.93098');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316deb', 'http://placehold.it/150x150', 'Concility', 'leilaware@concility.com', 'Rabat', 'Point', '-6.78478', '33.96255');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316dec', 'http://placehold.it/150x150', 'Cogentry', 'leilaware@cogentry.com', 'Rabat', 'Point', '-6.83578', '33.87532');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316ded', 'http://placehold.it/150x150', 'Zounds', 'leilaware@zounds.com', 'Rabat', 'Point', '-6.84032', '33.96739');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316dee', 'http://placehold.it/150x150', 'Unq', 'leilaware@unq.com', 'Rabat', 'Point', '-6.76689', '33.99387');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316def', 'http://placehold.it/150x150', 'Accusage', 'leilaware@accusage.com', 'Rabat', 'Point', '-6.75127', '33.85952');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316df0', 'http://placehold.it/150x150', 'Corecom', 'leilaware@corecom.com', 'Rabat', 'Point', '-6.76395', '33.90130');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316df1', 'http://placehold.it/150x150', 'Incubus', 'leilaware@incubus.com', 'Rabat', 'Point', '-6.83620', '33.92331');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316df2', 'http://placehold.it/150x150', 'Venoflex', 'leilaware@venoflex.com', 'Rabat', 'Point', '-6.79674', '33.88383');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316df3', 'http://placehold.it/150x150', 'Slambda', 'leilaware@slambda.com', 'Rabat', 'Point', '-6.84344', '33.98877');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316df4', 'http://placehold.it/150x150', 'Ecraze', 'leilaware@ecraze.com', 'Rabat', 'Point', '-6.77147', '33.88150');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316df5', 'http://placehold.it/150x150', 'Bullzone', 'leilaware@bullzone.com', 'Rabat', 'Point', '-6.81043', '33.82520');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316df6', 'http://placehold.it/150x150', 'Enomen', 'leilaware@enomen.com', 'Rabat', 'Point', '-6.84344', '33.95215');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316df7', 'http://placehold.it/150x150', 'Isoswitch', 'leilaware@isoswitch.com', 'Rabat', 'Point', '-6.75900', '33.86044');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316df8', 'http://placehold.it/150x150', 'Extragene', 'leilaware@extragene.com', 'Rabat', 'Point', '-6.81924', '33.98950');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316df9', 'http://placehold.it/150x150', 'Eyeris', 'leilaware@eyeris.com', 'Rabat', 'Point', '-6.75822', '33.93273');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316dfa', 'http://placehold.it/150x150', 'Verton', 'leilaware@verton.com', 'Rabat', 'Point', '-6.79216', '33.81497');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316dfb', 'http://placehold.it/150x150', 'Conjurica', 'leilaware@conjurica.com', 'Rabat', 'Point', '-6.75162', '33.91917');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316dfc', 'http://placehold.it/150x150', 'Sulfax', 'leilaware@sulfax.com', 'Rabat', 'Point', '-6.80167', '33.95460');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316dfd', 'http://placehold.it/150x150', 'Bleendot', 'leilaware@bleendot.com', 'Rabat', 'Point', '-6.83393', '33.92647');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316dfe', 'http://placehold.it/150x150', 'Kineticut', 'leilaware@kineticut.com', 'Rabat', 'Point', '-6.83193', '33.98657');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316dff', 'http://placehold.it/150x150', 'Petigems', 'leilaware@petigems.com', 'Rabat', 'Point', '-6.76126', '33.87188');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316e00', 'http://placehold.it/150x150', 'Adornica', 'leilaware@adornica.com', 'Rabat', 'Point', '-6.77999', '33.84045');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316e01', 'http://placehold.it/150x150', 'Injoy', 'leilaware@injoy.com', 'Rabat', 'Point', '-6.76078', '33.86574');
INSERT INTO `shops` VALUES ('5a0c6bd5fd3eb67969316e02', 'http://placehold.it/150x150', 'Flexigen', 'leilaware@flexigen.com', 'Rabat', 'Point', '-6.74693', '33.83824');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of users
-- ----------------------------
SET FOREIGN_KEY_CHECKS=1;
